"""Offline Vision-X local prototype. Run with: python app.py"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import threading
import time
from collections import deque
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "python"))
try:
    import cv2  # type: ignore
except Exception:
    cv2 = None


def config(name: str) -> dict:
    candidates = [ROOT / "config" / name, ROOT / name]
    for p in candidates:
        try:
            if p.exists():
                text = p.read_text(encoding="utf-8")
                return json.loads(text)
        except Exception:
            pass
    return {}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def iou(a, b) -> float:
    ax, ay, aw, ah = a; bx, by, bw, bh = b
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    inter = max(0, x2-x1) * max(0, y2-y1)
    return inter / max(1, aw*ah + bw*bh - inter)


class Tracker:
    """Session-local IoU tracker with stale-track suppression and light ReID."""

    def __init__(self, fps: float = 15.0):
        self.fps = fps
        self.tracks = {}
        self.next_id = 1
        cfg = config("tracker.yaml")
        self.max_lost = int(cfg.get("max_lost_frames", 12))
        self.min_iou = float(cfg.get("minimum_iou", 0.15))
        self.max_lost_seconds = float(cfg.get("max_lost_seconds", 2.5))
        self.reid_threshold = float(cfg.get("reid_similarity_threshold", 0.75))
        self.min_detection_confidence = float(cfg.get("min_detection_confidence", 0.25))
        self.recent_lost = {}

    @staticmethod
    def _descriptor_for_detection(detection, frame=None):
        bbox = detection.get("bbox") or [0, 0, 0, 0]
        if frame is not None and cv2 is not None:
            try:
                x, y, w, h = [int(v) for v in bbox]
                x0, y0 = max(0, x), max(0, y)
                x1, y1 = min(frame.shape[1], x + max(w, 1)), min(frame.shape[0], y + max(h, 1))
                crop = frame[y0:y1, x0:x1]
                if crop.size:
                    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
                    hist = cv2.calcHist([gray], [0], None, [16], [0, 256]).flatten() / max(1, hist.sum())
                    return [float(v) for v in hist.tolist()]
            except Exception:
                pass
        conf = float(detection.get("confidence", 0.0))
        cx = float(bbox[0] + bbox[2] / 2.0)
        cy = float(bbox[1] + bbox[3] / 2.0)
        return [conf, cx / 1000.0, cy / 1000.0, float(bbox[2]) / 1000.0, float(bbox[3]) / 1000.0]

    @staticmethod
    def _similarity(lhs, rhs):
        if not lhs or not rhs:
            return 0.0
        if len(lhs) != len(rhs):
            return 0.0
        similarity = 1.0 - sum(abs(float(a) - float(b)) for a, b in zip(lhs, rhs)) / max(1, len(lhs) * 1.25)
        return max(0.0, min(1.0, similarity))

    def _register_lost(self, track):
        if track.get("missed", 0) >= self.max_lost or (time.time() - float(track.get("last_seen", time.time()))) > self.max_lost_seconds:
            self.recent_lost[track["id"]] = {"appearance": track.get("appearance"), "last_seen": time.time()}
            self.tracks.pop(track["id"], None)
            self.recent_lost = {k: v for k, v in self.recent_lost.items() if time.time() - float(v.get("last_seen", 0)) < max(3.0, self.max_lost_seconds * 2.0)}

    def update(self, detections, frame=None):
        detections = [d for d in detections if float(d.get("confidence", 0.0)) >= self.min_detection_confidence]
        active_ids = [k for k, v in self.tracks.items() if v.get("status") != "MISSING"]
        used_t, used_d = set(), set()
        pairs = []
        for k in active_ids:
            for j, d in enumerate(detections):
                score = iou(self.tracks[k]["bbox"], d["bbox"])
                if score > self.min_iou:
                    pairs.append((score, k, j))
        for score, k, j in sorted(pairs, reverse=True):
            if k in used_t or j in used_d:
                continue
            d = detections[j]
            t = self.tracks[k]
            old = t["bbox"]
            ox, oy = old[0] + old[2] / 2.0, old[1] + old[3] / 2.0
            nx, ny = d["bbox"][0] + d["bbox"][2] / 2.0, d["bbox"][1] + d["bbox"][3] / 2.0
            t.update(d)
            t["velocity_px_s"] = [round((nx - ox) * self.fps, 1), round((ny - oy) * self.fps, 1)]
            t["appearance"] = self._descriptor_for_detection(d, frame)
            t["missed"] = 0
            t["age"] += 1
            t["status"] = "TRACKING" if t["age"] > 1 else "NEW"
            t["last_seen"] = time.time()
            used_t.add(k)
            used_d.add(j)

        # Track any currently visible person whose identity is re-acquired from recently-lost tracks.
        for j, d in enumerate(detections):
            if j in used_d:
                continue
            best_id = None
            best_score = 0.0
            for lost_id, lost in self.recent_lost.items():
                score = self._similarity(d.get("appearance", self._descriptor_for_detection(d, frame)), lost.get("appearance"))
                if score > best_score and score >= self.reid_threshold:
                    best_score = score
                    best_id = lost_id
            if best_id is not None:
                track = self.tracks.get(best_id)
                if track is None:
                    track = {"id": best_id, "age": 1, "missed": 0, "velocity_px_s": [0.0, 0.0], "born": time.time(), "status": "RE-IDENTIFIED"}
                    self.tracks[best_id] = track
                track.update(d)
                track["appearance"] = self._descriptor_for_detection(d, frame)
                track["status"] = "RE-IDENTIFIED"
                track["last_seen"] = time.time()
                track["missed"] = 0
                used_d.add(j)
                continue
            k = self.next_id
            self.next_id += 1
            self.tracks[k] = {**d, "id": k, "age": 1, "missed": 0, "velocity_px_s": [0.0, 0.0], "born": time.time(), "status": "NEW", "appearance": self._descriptor_for_detection(d, frame), "last_seen": time.time()}

        for k in list(self.tracks):
            if k in used_t:
                continue
            track = self.tracks[k]
            track["missed"] += 1
            track["status"] = "LOST" if track["missed"] <= self.max_lost else "MISSING"
            track["last_seen"] = time.time()
            if track["missed"] > self.max_lost or (time.time() - float(track.get("last_seen", time.time()))) > self.max_lost_seconds:
                self._register_lost(track)

        result = []
        for k, v in self.tracks.items():
            state = v.get("status", "TRACKING")
            if state in ("NEW", "RE-IDENTIFIED"):
                state = "TRACKING"
            result.append(dict(v, state=state, id=v.get("id", k)))
        return result


class VisionApp:
    def __init__(self, device=0, mode="human"):
        self.device, self.mode = device, mode
        self.cap = None
        self.lock = threading.RLock()
        self.frame = None
        self.tracks = []
        self.events = deque(maxlen=200)
        self.industrial = None
        self.gpu_available = False
        self.gpu_name = "CPU"
        self.model_device = "cpu"
        self.inference_ms = 0.0
        self.frame_number = 0
        self._last_track_states = {}
        self._status_counts = {"active": 0, "lost": 0, "warning": 0, "critical": 0}
        self.log_dir = ROOT / "logs"
        self.log_dir.mkdir(exist_ok=True)
        self.tracking_csv_path = self.log_dir / "person_tracking.csv"
        self.event_csv_path = self.log_dir / "person_events.csv"
        self._init_csv_logs()
        try:
            from industrial import IndustrialConfig, IndustrialMonitor
            self.industrial = IndustrialMonitor(IndustrialConfig.load(ROOT / "config" / "industrial.yaml"))
        except Exception as exc:
            self.events.append({"time": now(), "type": "industrial_config_error", "message": str(exc)})
        self.fps = 0.0; self.latency_ms = 0.0; self.processing_ms = 0.0
        self.camera_error = "OpenCV is not installed" if cv2 is None else "Camera not started"
        self.running = False
        self.tracker = Tracker(); self.tracker.fps = 15
        self.hog = None
        self.min_detection_confidence = 0.25
        self.custom_detector = None
        self.yolo_model = None
        self.detector_error = ""
        self._inference_lock = threading.Semaphore(1)
        self._last_detection_ts = 0.0
        self._adaptive_skip_frames = 0
        self._init_device_and_detector()
        self.homography = None
        self._load_homography()

    def _init_device_and_detector(self):
        try:
            import torch
            if torch.cuda.is_available():
                self.gpu_available = True
                self.gpu_name = torch.cuda.get_device_name(0)
                self.model_device = "cuda"
            else:
                self.gpu_name = "CPU"
                self.model_device = "cpu"
        except Exception:
            self.gpu_name = "CPU"
            self.model_device = "cpu"

        if cv2 is not None:
            try:
                self.hog = cv2.HOGDescriptor(); self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
            except AttributeError as exc:
                self.detector_error = f"OpenCV build lacks the HOG people baseline: {exc}"

        try:
            from ultralytics import YOLO
            local_candidates = [ROOT / "models" / "yolov8n.pt", ROOT / "weights" / "yolov8n.pt", ROOT / "yolov8n.pt"]
            for candidate in local_candidates:
                if candidate.exists():
                    try:
                        self.yolo_model = YOLO(str(candidate))
                        break
                    except Exception:
                        self.yolo_model = None
        except Exception:
            self.yolo_model = None

        det_cfg = config("detector.yaml")
        if det_cfg.get("backend") == "visionx_custom_grid":
            try:
                from visionx.detection import CustomGridDetector
                classes_path = ROOT / det_cfg.get("classes", "python/datasets/classes.txt")
                classes = [x.strip() for x in classes_path.read_text(encoding="utf-8").splitlines() if x.strip()]
                self.custom_detector = CustomGridDetector(str(ROOT / det_cfg.get("checkpoint", "models/detector.pt")), classes, float(det_cfg.get("confidence_threshold", .35)), float(det_cfg.get("nms_iou_threshold", .45)), str(det_cfg.get("device", self.model_device)))
                self.hog = None
            except Exception as exc:
                self.detector_error = str(exc)
                self.hog = None

    def _init_csv_logs(self):
        tracking_fields = ["Person_ID","Timestamp","Frame_Number","Detection_Confidence","BoundingBox_X","BoundingBox_Y","BoundingBox_Width","BoundingBox_Height","Center_X","Center_Y","Heading","Movement_Speed","Track_Status","Visibility_Level","Safety_Status","Reason"]
        event_fields = ["Person_ID","Timestamp","Event_Type","Safety_Status","Confidence","Reason","Recommended_Action"]
        for path, fields in ((self.tracking_csv_path, tracking_fields), (self.event_csv_path, event_fields)):
            if not path.exists():
                with path.open("w", newline="", encoding="utf-8") as handle:
                    writer = __import__("csv").DictWriter(handle, fieldnames=fields)
                    writer.writeheader()

    def _write_tracking_row(self, track):
        try:
            fields = ["Person_ID","Timestamp","Frame_Number","Detection_Confidence","BoundingBox_X","BoundingBox_Y","BoundingBox_Width","BoundingBox_Height","Center_X","Center_Y","Heading","Movement_Speed","Track_Status","Visibility_Level","Safety_Status","Reason"]
            payload = {
                "Person_ID": track.get("id", "N/A"),
                "Timestamp": now(),
                "Frame_Number": self.frame_number,
                "Detection_Confidence": round(float(track.get("confidence", 0.0)), 3),
                "BoundingBox_X": int(track["bbox"][0]),
                "BoundingBox_Y": int(track["bbox"][1]),
                "BoundingBox_Width": int(track["bbox"][2]),
                "BoundingBox_Height": int(track["bbox"][3]),
                "Center_X": int(track["bbox"][0] + track["bbox"][2] / 2),
                "Center_Y": int(track["bbox"][1] + track["bbox"][3] / 2),
                "Heading": self.direction(*track.get("velocity_px_s", [0.0, 0.0])),
                "Movement_Speed": round(float(math.hypot(*track.get("velocity_px_s", [0.0, 0.0]))), 2),
                "Track_Status": track.get("state", "TRACKING"),
                "Visibility_Level": round(max(0.0, min(1.0, float(track.get("confidence", 0.0)))), 3),
                "Safety_Status": track.get("safety_status", "SAFE"),
                "Reason": track.get("safety_reason", "Normal movement observed"),
            }
            with self.tracking_csv_path.open("a", newline="", encoding="utf-8") as handle:
                writer = __import__("csv").DictWriter(handle, fieldnames=fields)
                writer.writerow(payload)
        except Exception:
            pass

    def _write_event_log(self, track, event_type, safety_status, reason, recommended_action):
        try:
            payload = {
                "Person_ID": track.get("id", "N/A"),
                "Timestamp": now(),
                "Event_Type": event_type,
                "Safety_Status": safety_status,
                "Confidence": round(float(track.get("confidence", 0.0)), 3),
                "Reason": reason,
                "Recommended_Action": recommended_action,
            }
            with self.event_csv_path.open("a", newline="", encoding="utf-8") as handle:
                writer = __import__("csv").DictWriter(handle, fieldnames=["Person_ID","Timestamp","Event_Type","Safety_Status","Confidence","Reason","Recommended_Action"])
                writer.writerow(payload)
        except Exception:
            pass

    def _get_safety_state(self, track):
        status = str(track.get("state", "TRACKING")).upper()
        speed = math.hypot(*track.get("velocity_px_s", [0.0, 0.0]))
        confidence = float(track.get("confidence", 0.0))
        x, y, w, h = track.get("bbox", [0, 0, 0, 0])
        area = max(1.0, w * h)
        if status in {"LOST", "MISSING"}:
            return "MISSING", 0.9, "Person disappeared from the webcam view and could not be reacquired within the configured timeout.", "Verify reacquisition and continue monitoring."
        if speed < 5.0 and area < 2500:
            return "CRITICAL", max(0.5, confidence), "Person appears mostly stationary and possibly obstructed or immobile for too long.", "Require human verification and prioritize inspection."
        if speed < 10.0 or area < 6000:
            return "WARNING", max(0.55, confidence), "Person is partially occluded or moving unusually slowly compared with the expected range.", "Continue monitoring and re-check quickly."
        return "SAFE", max(0.7, confidence), "Normal movement and visibility detected in the webcam frame.", "Continue normal monitoring."

    def _load_homography(self):
        if cv2 is None: return
        c = config("localization.yaml")
        pts = c.get("image_points", [])
        world = c.get("world_points_m", [])
        if len(pts) == len(world) and len(pts) >= 4:
            import numpy as np
            self.homography = cv2.getPerspectiveTransform(np.array(pts[:4], dtype="float32"), np.array(world[:4], dtype="float32"))

    def _should_skip_detection(self):
        now = time.perf_counter()
        if self.gpu_available:
            return False
        if now - self._last_detection_ts < 0.10:
            return True
        self._last_detection_ts = now
        return False

    def _run_detector(self, frame):
        if self._should_skip_detection():
            return []
        if not self._inference_lock.acquire(blocking=False):
            return []
        try:
            detections = []
            start = time.perf_counter()
            if self.yolo_model is not None:
                try:
                    conf_threshold = max(0.25, float(config("detector.yaml").get("confidence_threshold", 0.35)))
                    results = self.yolo_model(frame, conf=conf_threshold, iou=0.45, verbose=False, device=self.model_device)
                    for result in results:
                        for box in getattr(result, "boxes", []):
                            if len(box.cls) == 0:
                                continue
                            cls_index = int(box.cls[0])
                            if cls_index != 0:
                                continue
                            conf = float(box.conf[0])
                            if conf < 0.25:
                                continue
                            x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
                            detections.append({"class_id": 0, "class_name": "person", "confidence": round(conf, 3), "bbox": [int(x1), int(y1), max(1, int(x2 - x1)), max(1, int(y2 - y1))]})
                except Exception:
                    detections = []
            elif self.custom_detector is not None:
                detections = [dict(class_id=d.class_id, class_name=d.class_name, confidence=round(float(d.confidence),3), bbox=[int(v) for v in d.bounding_box]) for d in self.custom_detector.detect(frame, time.time())]
            elif self.mode == "human" and self.hog is not None:
                rects, weights = self.hog.detectMultiScale(frame, winStride=(8,8), padding=(8,8), scale=1.05)
                detections = [dict(class_id=0, class_name="person", confidence=round(float(weights[i]), 3), bbox=list(map(int, r))) for i,r in enumerate(rects)]
            self.inference_ms = (time.perf_counter() - start) * 1000.0
            self._last_detection_ts = time.perf_counter()
            return detections
        finally:
            self._inference_lock.release()

    def start(self):
        self.running = True
        if cv2 is None: return
        self.cap = cv2.VideoCapture(self.device)
        cam = config("camera.yaml")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(cam.get("width", 640)))
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(cam.get("height", 480)))
        if not self.cap.isOpened():
            self.camera_error = f"Could not open camera device {self.device}"; self.cap.release(); self.cap = None; return
        self.camera_error = ""
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        prev = time.perf_counter()
        while self.running and self.cap:
            tick = time.perf_counter()
            ok, frame = self.cap.read()
            if not ok:
                self.camera_error = "Camera read failed"; time.sleep(.1); continue
            start = time.perf_counter()
            detections = self._run_detector(frame)
            self.tracker.fps = 1 / max(.001, time.perf_counter() - prev); prev = time.perf_counter()
            updated_tracks = self.tracker.update(detections, frame)
            self.frame_number += 1
            for t in updated_tracks:
                x, y, w, h = t["bbox"]
                safety, confidence, reason, action = self._get_safety_state(t)
                t["safety_status"] = safety
                t["safety_confidence"] = confidence
                t["safety_reason"] = reason
                t["recommended_action"] = action
                if t.get("state") in {"LOST", "MISSING"} and self._last_track_states.get(t["id"]) != t.get("state"):
                    self._write_event_log(t, "lost", safety, reason, action)
                if self._last_track_states.get(t["id"]) != t.get("state") and t.get("state") == "TRACKING":
                    self._write_event_log(t, "detected", safety, reason, action)
                if self._last_track_states.get(t["id"]) != t.get("state") and t.get("state") == "RE-IDENTIFIED":
                    self._write_event_log(t, "re-identified", safety, reason, action)
                self._last_track_states[t["id"]] = t.get("state")
                self._write_tracking_row(t)
                if cv2 is not None:
                    color = (70, 220, 150)
                    if safety == "WARNING":
                        color = (0, 165, 255)
                    elif safety == "CRITICAL":
                        color = (0, 0, 255)
                    elif safety == "MISSING":
                        color = (128, 128, 128)
                    cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                    cv2.putText(frame, f"ID {t['id']:02d} {safety} {t['confidence']:.2f}", (max(0, x), max(20, y - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
            self.processing_ms = (time.perf_counter() - start) * 1000
            self.fps = 0.9 * self.fps + 0.1 / max(0.001, time.perf_counter() - tick) if self.fps else 1 / max(0.001, time.perf_counter() - tick)
            with self.lock:
                self.frame = frame
                self.tracks = updated_tracks
                self.camera_error = ""

    def track_payload(self):
        with self.lock:
            result = []
            for t in self.tracks:
                x, y, w, h = t["bbox"]
                px = x + w / 2
                py = y + h
                coord = self.localize(px, py)
                vx, vy = t["velocity_px_s"]
                safety, confidence, reason, action = self._get_safety_state(t)
                t["safety_status"] = safety
                t["safety_confidence"] = confidence
                t["safety_reason"] = reason
                t["recommended_action"] = action
                result.append({
                    "id": f"{self.mode.title()}-{t['id']:03d}",
                    "class": t["class_name"],
                    "class_name": t["class_name"],
                    "confidence": t["confidence"],
                    "bbox": t["bbox"],
                    "x_m": coord[0] if coord[0] is not None else None,
                    "y_m": coord[1] if coord[1] is not None else None,
                    "world_x": coord[0] if coord[0] is not None else None,
                    "world_y": coord[1] if coord[1] is not None else None,
                    "speed_px_s": round(math.hypot(vx, vy), 1),
                    "direction": self.direction(vx, vy),
                    "state": t["state"],
                    "age_frames": t["age"],
                    "last_seen": now(),
                    "safety_status": safety,
                    "safety_confidence": confidence,
                    "safety_reason": reason,
                    "recommended_action": action,
                    "visibility_level": max(0.0, min(1.0, float(t.get("confidence", 0.0)))),
                    "track_status": t["state"],
                })
            if self.mode == "industrial" and self.industrial is not None:
                raw = [{"id": t["id"], "class_name": t["class_name"], "x_m": self.localize(t["bbox"][0] + t["bbox"][2] / 2, t["bbox"][1] + t["bbox"][3])[0], "y_m": self.localize(t["bbox"][0] + t["bbox"][2] / 2, t["bbox"][1] + t["bbox"][3])[1], "state": t["state"]} for t in self.tracks]
                self.industrial.update(raw)
                self.events = deque(self.industrial.events(), maxlen=200)
            self._status_counts = {"active": sum(1 for t in result if t["state"] not in {"LOST", "MISSING"}), "lost": sum(1 for t in result if t["state"] in {"LOST", "MISSING"}), "warning": sum(1 for t in result if t["safety_status"] == "WARNING"), "critical": sum(1 for t in result if t["safety_status"] == "CRITICAL")}
            return result

    def localize(self, x, y):
        if cv2 is None or self.homography is None: return None, None
        import numpy as np
        p = cv2.perspectiveTransform(np.array([[[x, y]]], dtype="float32"), self.homography)[0][0]
        return round(float(p[0]), 2), round(float(p[1]), 2)

    @staticmethod
    def direction(vx, vy):
        if math.hypot(vx, vy) < 8:
            return "STATIONARY"
        return ("S" if vy > 0 else "N") + ("E" if vx > 0 else "W")

    def status(self):
        online = bool(self.cap and self.cap.isOpened() and not self.camera_error)
        det_name = "YOLO person detector" if self.yolo_model is not None else ("custom trained detector" if self.custom_detector else ("OpenCV HOG people baseline" if self.hog else (self.detector_error or "Unavailable (install opencv-python)")))
        detector_active = self.yolo_model is not None or self.custom_detector is not None or (self.hog is not None and self.mode == "human")
        active_people = sum(1 for t in self.tracks if str(t.get("state", "TRACKING")).upper() not in {"LOST", "MISSING"})
        lost_people = sum(1 for t in self.tracks if str(t.get("state", "TRACKING")).upper() in {"LOST", "MISSING"})
        critical = sum(1 for t in self.tracks if str(t.get("safety_status", "SAFE")).upper() == "CRITICAL")
        warning = sum(1 for t in self.tracks if str(t.get("safety_status", "SAFE")).upper() == "WARNING")
        return {
            "product": "OFFLINE VISION-X",
            "mode": self.mode,
            "camera_online": online,
            "camera_status": "online" if online else "unavailable",
            "camera_error": self.camera_error,
            "camera_message": self.camera_error or "Camera connected",
            "detector": det_name if detector_active else ("No industrial detector configured" if self.mode == "industrial" else "Unavailable (install opencv-python)"),
            "model_status": "YOLO" if self.yolo_model is not None else ("CUSTOM TRAINED MODEL" if self.custom_detector else ("BASELINE" if self.hog and self.mode == "human" else "NO DETECTOR")),
            "fps": round(self.fps, 1),
            "processor": self.gpu_name,
            "device": self.gpu_name,
            "gpu_available": self.gpu_available,
            "device_type": self.model_device,
            "inference_time_ms": round(self.inference_ms, 2),
            "processing_ms": round(self.processing_ms, 1),
            "latency_ms": round(self.processing_ms, 1),
            "active_tracks": active_people,
            "lost_tracks": lost_people,
            "detection_count": len(self.tracks),
            "active_persons": active_people,
            "lost_persons": lost_people,
            "critical": critical,
            "warnings": warning,
            "localization": "calibrated homography" if self.homography is not None else "not calibrated",
            "localization_status": "Calibrated camera plane" if self.homography is not None else "Positions unavailable · camera calibration required",
            "room_width_m": config("localization.yaml").get("room_width_m", 10),
            "room_height_m": config("localization.yaml").get("room_height_m", 8),
            "offline": True,
            "lost_track_timeout_seconds": self.tracker.max_lost_seconds,
            "reid_threshold": self.tracker.reid_threshold,
            "fps_readout": f"{round(self.fps, 1)} FPS",
        }


class Handler(BaseHTTPRequestHandler):
    app: VisionApp
    def log_message(self,*args): pass
    def send_json(self,obj):
        data=json.dumps(obj).encode(); self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(data))); self.send_header("Access-Control-Allow-Origin","*"); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/api/status": return self.send_json(self.app.status())
        if path=="/api/tracks": return self.send_json(self.app.track_payload())
        if path=="/api/events": return self.send_json(list(self.app.events))
        if path=="/api/mode": return self.send_json({"mode":self.app.mode})
        if path=="/video.mjpg":
            if cv2 is None or self.app.cap is None or self.app.camera_error:
                self.send_error(503, "CAMERA UNAVAILABLE"); return
            self.send_response(200); self.send_header("Cache-Control","no-store"); self.send_header("Content-Type","multipart/x-mixed-replace; boundary=frame"); self.end_headers()
            while True:
                if self.app.camera_error or self.app.cap is None: break
                with self.app.lock: frame=self.app.frame.copy() if self.app.frame is not None else None
                if frame is None:
                    time.sleep(.25); continue
                ok,buf=cv2.imencode(".jpg",frame)
                if not ok: continue
                try: self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"+buf.tobytes()+b"\r\n"); time.sleep(.05)
                except (BrokenPipeError,ConnectionResetError): break
            return
        if path.startswith("/dashboard/"):
            name=Path(path.removeprefix("/dashboard/")).name
            if name in {"app.js","styles.css"}:
                file=ROOT/"dashboard"/name
                if file.exists():
                    data=file.read_bytes(); self.send_response(200); self.send_header("Content-Type","text/javascript; charset=utf-8" if name.endswith(".js") else "text/css; charset=utf-8"); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path in ("/",""):
            file=ROOT/"dashboard"/"index.html"
            if file.exists():
                data=file.read_bytes(); self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8"); self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
        self.send_error(404)

    def do_POST(self):
        if urlparse(self.path).path != "/api/mode":
            self.send_error(404); return
        try:
            length=int(self.headers.get("Content-Length","0")); body=json.loads(self.rfile.read(length) or b"{}")
            mode=body.get("mode")
            if mode not in ("human","industrial"):
                self.send_error(400,"mode must be human or industrial"); return
            self.app.mode=mode
            self.send_json({"mode":mode,"model_status":"BASELINE" if mode=="human" and self.app.hog else "NO DETECTOR"})
        except (ValueError,TypeError): self.send_error(400,"invalid JSON")


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--host",default=None); ap.add_argument("--port",type=int,default=8765); ap.add_argument("--camera",type=int,default=None); ap.add_argument("--mode",choices=["human","industrial"],default=None)
    args=ap.parse_args(); nc=config("network.yaml"); cc=config("camera.yaml")
    app=VisionApp(args.camera if args.camera is not None else int(cc.get("device_id",0)), args.mode or config("system.yaml").get("mode","human"))
    Handler.app=app; app.start()
    host=args.host or nc.get("host","0.0.0.0")
    server=ThreadingHTTPServer((host,args.port),Handler)
    print(f"Offline Vision-X: http://127.0.0.1:{args.port}  (LAN bind {host}; camera: {app.camera_error or 'online'})")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        app.running=False; server.server_close()
        if app.cap: app.cap.release()

if __name__=="__main__": main()
